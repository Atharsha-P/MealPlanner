const mongoose = require("mongoose");
const Recipe = require("./models/Recipe"); // Assuming your model is in `models/recipe.js`

mongoose.connect("mongodb://localhost:27017/mealplanner", { useNewUrlParser: true, useUnifiedTopology: true });

const recipes = [
  {
    "title": "Idli",
    "image": "https://www.indianhealthyrecipes.com/wp-content/uploads/2022/04/idli-recipe-500x500.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Gluten-Free Diet", "Low-Calorie Diet", "Diabetic Diet", "Heart-Healthy Diet"],
    "ingredients": ["Rice", "Urad dal", "Fenugreek seeds"],
    "recipeLink": "https://www.indianhealthyrecipes.com/soft-idli-recipe-using-idli-rava/"
  },
  {
    "title": "Dosa",
    "image": "https://www.awesomecuisine.com/wp-content/uploads/2009/06/Plain-Dosa.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Gluten-Free Diet", "Low-Fat Diet", "Diabetic Diet", "Vegan Diet"],
    "ingredients": ["Rice", "Urad dal", "Fenugreek seeds"],
    "recipeLink": "https://www.awesomecuisine.com/recipes/1900/plain-dosa/"
  },
  {
    "title": "Upma",
    "image": "https://www.vegrecipesofindia.com/wp-content/uploads/2009/08/upma-recipe-1.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Low-Fat Diet", "High-Fiber Diet", "Diabetic Diet", "Heart-Healthy Diet"],
    "ingredients": ["Semolina", "Vegetables", "Spices", "Water"],
    "recipeLink": "https://www.vegrecipesofindia.com/upma-savoury-south-indian-breakfast-recipe-made-with-semolina/"
  },
  {
    "title": "Poha",
    "image": "https://www.indianhealthyrecipes.com/wp-content/uploads/2020/01/poha.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Low-Glycemic Index Diet", "Diabetic Diet", "High-Iron Diet", "Vegan Diet"],
    "ingredients": ["Flattened rice", "Onion", "Peanuts", "Spices"],
    "recipeLink": "https://www.indianhealthyrecipes.com/poha-recipe-kanda-batata-poha/"
  },

  {
    "title": "Besan Chilla",
    "image": "https://shwetainthekitchen.com/wp-content/uploads/2023/09/Besan-Chilla.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Gluten-Free Diet", "Diabetic Diet", "High-Protein Diet", "Low-Carb Diet"],
    "ingredients": ["Chickpea flour", "Vegetables", "Spices"],
    "recipeLink": "https://shwetainthekitchen.com/tomato-omelette-besan-cheela-besan-chilla/"
  },
  {
    "title": "Pesarattu",
    "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9gtIlXWjURLFe-3q8r1aFZrCWaRkFh9Rjcw&s",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["High-Protein Diet", "Vegan Diet", "Low-Carb Diet", "Heart-Healthy Diet"],
    "ingredients": ["Green gram", "Spices", "Water"],
    "recipeLink": "https://www.indianhealthyrecipes.com/andhra-pesarattu-whole-moong-dosa/"
  },
  
  
  {
    "title": "Bread Upma",
    "image": "https://www.indianhealthyrecipes.com/wp-content/uploads/2022/06/bread-upma-recipe.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Vegetarian Diet", "High-Fiber Diet", "Heart-Healthy Diet", "DASH Diet"],
    "ingredients": ["Bread", "Vegetables", "Spices"],
    "recipeLink": "https://www.indianhealthyrecipes.com/bread-upma-recipe/"
  },
  {
    "title": "Vegetable Sandwich",
    "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDatWDLCQMSnJpAg0bIVFeoo-9oDOkp99OIw&s",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Vegetarian Diet", "High-Fiber Diet", "Plant-Based Diet", "Whole30 Diet"],
    "ingredients": ["Whole wheat bread", "Vegetables", "Butter"],
    "recipeLink": "https://bachelorrecipe.com/vegetable-sandwich-recipe/"
  },
  {
    "title": "Sprouts Salad",
    "image": "https://www.indianhealthyrecipes.com/wp-content/uploads/2022/04/sprouts-salad-recipe.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Vegan Diet", "High-Protein Diet", "Low-Carb Diet", "Diabetic Diet"],
    "ingredients": ["Sprouts", "Vegetables", "Lemon juice"],
    "recipeLink": "https://www.indianhealthyrecipes.com/sprouted-moong-salad-recipe/"
  },
  {
    "title": "Rava Idli",
    "image": "https://www.vegrecipesofindia.com/wp-content/uploads/2013/11/rava-idli-5.jpg",
    "source": "Indian Healthy Recipes",
    "mealType": "Breakfast",
    "dietary": ["Gluten-Free Diet", "Diabetic Diet", "Heart-Healthy Diet", "Vegetarian Diet"],
    "ingredients": ["Semolina", "Yogurt", "Spices"],
    "recipeLink": "https://www.indianhealthyrecipes.com/rava-idli-recipe/"
  }
];


Recipe.insertMany(recipes)
  .then(() => {
    console.log("Data inserted");
    mongoose.connection.close();
  })
  .catch((err) => console.log(err));
