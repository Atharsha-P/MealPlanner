import mongoose from "mongoose";

const mealSchema = new mongoose.Schema({
  name: String,
  image: String,
  category: String,
  dietary: String,
  recipeLink: String,  
});

export default mongoose.model("Meal", mealSchema);
