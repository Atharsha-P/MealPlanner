const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

mongoose
  .connect("mongodb://localhost:27017/mealplanner", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log("Error: ", err));

// Recipe Schema
const recipeSchema = new mongoose.Schema({
  title: String,
  image: String,
  source: String,
  mealType: String,
  dietary: [String],
  ingredients: [String],
  recipeLink: String,
});

const Recipe = mongoose.model("Recipe", recipeSchema);

// Planned Meal Schema
const plannedMealSchema = new mongoose.Schema({
  title: String,
  image: String,
  source: String,
  mealType: String,
  dietary: [String],
  ingredients: [String],
  recipeLink: String,
});

const PlannedMeal = mongoose.model("PlannedMeal", plannedMealSchema);

// API to fetch recipes based on filters
app.get("/recipes", async (req, res) => {
  try {
    const { mealType = "", dietary = "", ingredient = "" } = req.query;
    let query = {};

    if (mealType) query.mealType = mealType;
    if (dietary) query.dietary = { $in: dietary.split(",") };

    if (ingredient) {
      const ingredientArray = ingredient.split(",").map((ing) => ing.trim());
      query.$or = [
        { ingredients: { $in: ingredientArray.map(ing => new RegExp(ing, "i")) } }, // Case-insensitive search in ingredients
        { title: { $regex: ingredientArray.join("|"), $options: "i" } } // Case-insensitive search in title
      ];
    }

    const recipes = await Recipe.find(query);
    res.json(recipes);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "An error occurred while fetching recipes" });
  }
});

// API to add recipe to planned meals
app.post("/plannedMeal", async (req, res) => {
  try {
    const newMeal = new PlannedMeal(req.body);
    await newMeal.save();
    res.status(201).json(newMeal);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "An error occurred while adding to planned meals" });
  }
});

// API to get all planned meals
app.get("/plannedMeal", async (req, res) => {
  try {
    const meals = await PlannedMeal.find();
    res.json(meals);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "An error occurred while fetching planned meals" });
  }
});

// API to delete a planned meal
app.delete("/plannedMeal/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await PlannedMeal.findByIdAndDelete(id);
    res.status(200).json({ message: "Meal removed from planned meals" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "An error occurred while deleting the planned meal" });
  }
});

// Start server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));